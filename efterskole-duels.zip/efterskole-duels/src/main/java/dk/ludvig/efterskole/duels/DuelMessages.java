package dk.ludvig.efterskole.duels;

import dk.ludvig.efterskole.duels.model.ActiveDuel;
import dk.ludvig.efterskole.duels.model.PendingChallenge;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.entity.Player;

import java.time.Duration;
import java.util.UUID;

/**
 * All player-facing text lives here, deliberately separate from the
 * state-machine logic in DuelManager, so wording/colours can be tuned
 * freely without risking a behavioural bug. Treat everything here as a
 * first draft - some flows (announceAccepted/Cancelled/Start) are left
 * as clearly marked stubs since exact copy is low-risk to add later;
 * the effort so far went into the challenge prompt, since that's the
 * one you specifically asked to get right (clickable + idiot-proof).
 */
public final class DuelMessages {

    private final DuelPlugin plugin;

    public DuelMessages(DuelPlugin plugin) {
        this.plugin = plugin;
    }

    public void announceChallenge(PendingChallenge challenge) {
        Player challenger = Bukkit.getPlayer(challenge.challenger());
        String challengerName = challenger != null ? challenger.getName() : "Someone";

        for (UUID id : challenge.invited()) {
            Player target = Bukkit.getPlayer(id);
            if (target == null) continue;

            Component acceptCmd = Component.text("/duel accept", NamedTextColor.GREEN, TextDecoration.BOLD);
            Component declineCmd = Component.text("/duel decline", NamedTextColor.RED, TextDecoration.BOLD);

            if (plugin.getConfig().getBoolean("accept-prompt.clickable-for-java", true)) {
                acceptCmd = acceptCmd.clickEvent(ClickEvent.runCommand("/duel accept"))
                        .hoverEvent(HoverEvent.showText(Component.text("Click to accept")));
                declineCmd = declineCmd.clickEvent(ClickEvent.runCommand("/duel decline"))
                        .hoverEvent(HoverEvent.showText(Component.text("Click to decline")));
            }

            // The commands are ALWAYS spelled out in plain text, click
            // or no click - clicking is a bonus for Java players, never
            // the only way to respond. Bedrock/PE players (and anyone
            // who just doesn't notice a click prompt) get an
            // unambiguous instruction sitting right there regardless.
            Component message = Component.text()
                    .append(Component.text("▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬", NamedTextColor.GOLD))
                    .append(Component.newline())
                    .append(Component.text("⚔ ", NamedTextColor.YELLOW))
                    .append(Component.text(challengerName, NamedTextColor.YELLOW, TextDecoration.BOLD))
                    .append(Component.text(" has challenged you to a duel!", NamedTextColor.YELLOW))
                    .append(Component.newline())
                    .append(Component.text("Type ", NamedTextColor.GRAY))
                    .append(acceptCmd)
                    .append(Component.text(" to accept, or ", NamedTextColor.GRAY))
                    .append(declineCmd)
                    .append(Component.text(" to decline.", NamedTextColor.GRAY))
                    .append(Component.newline())
                    .append(Component.text("This expires in 60 seconds.", NamedTextColor.DARK_GRAY))
                    .append(Component.newline())
                    .append(Component.text("▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬", NamedTextColor.GOLD))
                    .build();

            target.sendMessage(message);

            if (plugin.getConfig().getBoolean("accept-prompt.show-title", true)) {
                target.showTitle(Title.title(
                        Component.text("⚔ DUEL CHALLENGE", NamedTextColor.GOLD, TextDecoration.BOLD),
                        Component.text("from " + challengerName + " - see chat", NamedTextColor.YELLOW),
                        Title.Times.times(Duration.ofMillis(250), Duration.ofSeconds(3), Duration.ofMillis(500))
                ));
            }

            if (plugin.getConfig().getBoolean("accept-prompt.play-sound", true)) {
                String soundName = plugin.getConfig().getString("accept-prompt.sound", "UI_TOAST_CHALLENGE_COMPLETE");
                try {
                    Sound sound = Sound.valueOf(soundName);
                    target.playSound(target.getLocation(), sound, 1f, 1f);
                } catch (IllegalArgumentException e) {
                    plugin.getLogger().warning("Unknown sound in config, skipping: " + soundName);
                }
            }
        }
    }

    public void announceAccepted(PendingChallenge challenge, UUID whoJustAccepted) {
        // TODO: "X accepted - still waiting on Y, Z" to everyone
        // still pending on this challenge. Low-risk to fill in later.
    }

    public void announceCancelled(PendingChallenge challenge, UUID actorOrNull, String reason) {
        // TODO: tell everyone involved the challenge is off, and why
        // ("declined by X" / "timed out"). Low-risk to fill in later.
    }

    public void announceStart(ActiveDuel duel) {
        // TODO: "The duel begins!" to participants. Low-risk to fill in later.
    }

    public void announceElimination(ActiveDuel duel, UUID loser, UUID attackerOrNull, String causeDescription) {
        if (!plugin.getConfig().getBoolean("messages.broadcast-publicly", true)) return;

        Player loserPlayer = Bukkit.getPlayer(loser);
        String name = loserPlayer != null ? loserPlayer.getName() : "A player";

        Bukkit.broadcast(Component.text(name + " " + causeDescription + ".",
                NamedTextColor.GRAY, TextDecoration.ITALIC));
    }

    public void announceWinner(ActiveDuel duel, UUID winnerOrNull) {
        if (!plugin.getConfig().getBoolean("messages.broadcast-publicly", true)) return;
        if (winnerOrNull == null) return; // draw - the elimination messages already told the story

        Player winner = Bukkit.getPlayer(winnerOrNull);
        String name = winner != null ? winner.getName() : "Someone";
        Bukkit.broadcast(Component.text("🏆 " + name + " wins the duel!", NamedTextColor.GOLD, TextDecoration.BOLD));
    }

    public String errorText(String key) {
        // TODO: proper, per-key, nicely coloured copy - this is a
        // functional placeholder so the command flow works end to end
        // before we polish wording.
        return "§c" + key.replace('-', ' ').replace(":", ": ");
    }
}
