package dk.ludvig.efterskole.duels;

import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;

/**
 * Tiny per-player store for the one thing that needs to persist across
 * restarts: whether a player has opted out of duels via /duel disable.
 * A flat YAML file is plenty for ~70 players' worth of a single
 * boolean each - no need for a database here.
 */
public final class PlayerPrefs {

    private final DuelPlugin plugin;
    private final File file;
    private final YamlConfiguration yaml;
    private final Map<UUID, Boolean> cache = new HashMap<>();

    public PlayerPrefs(DuelPlugin plugin) {
        this.plugin = plugin;
        String fileName = plugin.getConfig().getString("storage.player-prefs-file", "playerprefs.yml");
        this.file = new File(plugin.getDataFolder(), fileName);
        this.yaml = YamlConfiguration.loadConfiguration(file);

        for (String key : yaml.getKeys(false)) {
            try {
                cache.put(UUID.fromString(key), yaml.getBoolean(key));
            } catch (IllegalArgumentException ignored) {
                plugin.getLogger().warning("Ignoring malformed UUID in " + fileName + ": " + key);
            }
        }
    }

    public boolean duelsEnabled(UUID player) {
        return cache.getOrDefault(player, true); // opted in by default
    }

    public void setDuelsEnabled(UUID player, boolean enabled) {
        cache.put(player, enabled);
        yaml.set(player.toString(), enabled);
        try {
            yaml.save(file);
        } catch (IOException e) {
            plugin.getLogger().log(Level.WARNING, "Could not save player duel preferences", e);
        }
    }
}
