package dk.ludvig.efterskole.duels.model;

import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * A duel that's actually happening - everyone invited has accepted.
 * Supports 2 or more participants (FFA); a participant is "eliminated"
 * (frozen out of further duel damage) rather than removed outright, so
 * a final standings message is possible later if wanted.
 */
public final class ActiveDuel {

    private final Set<UUID> participants;
    private final Set<UUID> eliminated = new LinkedHashSet<>();

    // Per-player "who last hit me, and when" - used only to build a
    // vanilla-style cause-of-death for indirect causes (fall, fire,
    // lava) that don't carry an attacker of their own on the event
    // itself. Entries older than a few seconds are ignored on read.
    private final Map<UUID, LastHit> lastHitBy = new HashMap<>();

    public ActiveDuel(Set<UUID> participants) {
        this.participants = new LinkedHashSet<>(participants);
    }

    public Set<UUID> participants() { return participants; }
    public Set<UUID> eliminated() { return eliminated; }

    public boolean isOver() {
        return (participants.size() - eliminated.size()) <= 1;
    }

    /** Null if there's no single survivor (e.g. a simultaneous double-elimination). */
    public UUID winner() {
        for (UUID p : participants) {
            if (!eliminated.contains(p)) return p;
        }
        return null;
    }

    public void recordHit(UUID victim, UUID attacker) {
        lastHitBy.put(victim, new LastHit(attacker, System.currentTimeMillis()));
    }

    public LastHit lastHitOn(UUID victim, long maxAgeMillis) {
        LastHit hit = lastHitBy.get(victim);
        if (hit == null) return null;
        return (System.currentTimeMillis() - hit.timestamp() <= maxAgeMillis) ? hit : null;
    }

    public record LastHit(UUID attacker, long timestamp) {}
}
