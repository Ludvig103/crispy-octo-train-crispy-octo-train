package dk.ludvig.efterskole.duels;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Protects a player for a short window right after they leave a duel
 * (win, lose, or forfeit) from residual damage they were already
 * exposed to mid-fight - still on fire, still standing in lava, still
 * underwater. Deliberately narrow: it only ever ignores the specific
 * causes listed in config, only for the specific player who just left
 * a duel, and the window is a fixed reset (never additive/stackable).
 * It is NOT a general "can't die" flag.
 */
public final class GracePeriod {

    private final DuelPlugin plugin;
    private final Map<UUID, Long> protectedUntil = new HashMap<>();

    public GracePeriod(DuelPlugin plugin) {
        this.plugin = plugin;
    }

    public void protect(UUID player) {
        int seconds = plugin.getConfig().getInt("grace-period.seconds", 4);
        // Fixed reset, not additive - re-triggering (e.g. finishing
        // another duel soon after) overwrites the window, never stacks.
        protectedUntil.put(player, System.currentTimeMillis() + seconds * 1000L);

        Player p = plugin.getServer().getPlayer(player);
        if (p == null) return;

        // Immediate cleanup rather than leaning on the timer alone.
        p.setFireTicks(0);

        if (plugin.getConfig().getBoolean("grace-period.attempt-safe-teleport", true)
                && isInHazard(p.getLocation())) {
            Location safe = findNearbySafeLocation(p.getLocation(),
                    plugin.getConfig().getInt("grace-period.safe-teleport-search-radius", 6));
            if (safe != null) p.teleport(safe);
        }
    }

    public boolean isCurrentlyProtected(UUID player, DamageCause cause) {
        Long until = protectedUntil.get(player);
        if (until == null || until < System.currentTimeMillis()) return false;

        List<String> causes = plugin.getConfig().getStringList("grace-period.protected-causes");
        return causes.contains(cause.name());
    }

    private boolean isInHazard(Location loc) {
        Material feet = loc.getBlock().getType();
        Material below = loc.clone().subtract(0, 1, 0).getBlock().getType();
        return feet == Material.LAVA || feet == Material.FIRE || below == Material.LAVA;
    }

    /**
     * Simple outward block scan for the nearest standable, hazard-free
     * spot. Deliberately unsophisticated for this first pass - good
     * enough for "knocked a couple blocks into a lava pool"; not meant
     * to solve "dropped in the middle of a whole lava ocean" (that's
     * what the timed fallback in isCurrentlyProtected is for).
     */
    private Location findNearbySafeLocation(Location center, int radius) {
        for (int r = 1; r <= radius; r++) {
            for (int dx = -r; dx <= r; dx++) {
                for (int dz = -r; dz <= r; dz++) {
                    for (int dy = -2; dy <= 2; dy++) {
                        Location candidate = center.clone().add(dx, dy, dz);
                        if (isSafeStandingSpot(candidate)) return candidate;
                    }
                }
            }
        }
        return null;
    }

    private boolean isSafeStandingSpot(Location loc) {
        Material ground = loc.clone().subtract(0, 1, 0).getBlock().getType();
        Material feet = loc.getBlock().getType();
        Material head = loc.clone().add(0, 1, 0).getBlock().getType();
        return ground.isSolid() && !isHazardMaterial(ground)
                && feet == Material.AIR && head == Material.AIR;
    }

    private boolean isHazardMaterial(Material m) {
        return m == Material.LAVA || m == Material.FIRE || m == Material.MAGMA_BLOCK;
    }
}
