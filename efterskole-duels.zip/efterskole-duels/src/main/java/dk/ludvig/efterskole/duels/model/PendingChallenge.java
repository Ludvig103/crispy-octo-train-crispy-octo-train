package dk.ludvig.efterskole.duels.model;

import org.bukkit.scheduler.BukkitTask;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.UUID;

/**
 * A challenge that has been issued but not yet fully accepted. Covers
 * both 1v1 and FFA (3+) challenges - a 1v1 is just an invited-set of
 * size 1. Every player named in {@link #everyone()} is locked out of
 * starting or receiving any other challenge until this one resolves,
 * one way or another.
 */
public final class PendingChallenge {

    private final UUID challenger;
    private final Set<UUID> invited;   // everyone who still needs to respond
    private final Set<UUID> accepted;  // everyone who has already said yes
    private BukkitTask timeoutTask;    // auto-declines this after invite.timeout-seconds

    public PendingChallenge(UUID challenger, Set<UUID> invited) {
        this.challenger = challenger;
        this.invited = new LinkedHashSet<>(invited);
        this.accepted = new LinkedHashSet<>();
    }

    public UUID challenger() { return challenger; }
    public Set<UUID> invited() { return invited; }
    public Set<UUID> accepted() { return accepted; }

    public boolean isFullyAccepted() {
        return accepted.containsAll(invited);
    }

    /** Everyone involved in this challenge, challenger included. */
    public Set<UUID> everyone() {
        Set<UUID> all = new LinkedHashSet<>(invited);
        all.add(challenger);
        return all;
    }

    public void setTimeoutTask(BukkitTask task) { this.timeoutTask = task; }
    public BukkitTask timeoutTask() { return timeoutTask; }
}
