package dk.ludvig.efterskole.duels;

import dk.ludvig.efterskole.duels.model.ActiveDuel;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public final class DamageListener implements Listener {

    private final DuelPlugin plugin;

    public DamageListener(DuelPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player victim)) return;
        UUID id = victim.getUniqueId();

        // Layer 1: the post-duel safety net for residual damage.
        if (plugin.gracePeriod().isCurrentlyProtected(id, event.getCause())) {
            event.setCancelled(true);
            return;
        }

        // Layer 2: the actual "would this end the duel" check.
        Optional<ActiveDuel> maybeDuel = plugin.duelManager().activeDuelOf(id);
        if (maybeDuel.isEmpty()) return;
        ActiveDuel duel = maybeDuel.get();
        if (duel.eliminated().contains(id)) return; // cleanup already running elsewhere

        UUID attacker = resolveAttacker(event).orElse(null);

        if (!causeCanEndDuel(event.getCause(), attacker, duel)) return;

        double resultingHealth = victim.getHealth() - event.getFinalDamage();
        if (resultingHealth > 0) {
            // Not fatal - just remember who hit them, in case a later,
            // indirect hit (e.g. a fall a moment from now) needs to be
            // attributed to this fight for the death message.
            if (attacker != null) duel.recordHit(id, attacker);
            return;
        }

        // This hit would have ended them. Cancel it outright rather
        // than setting health manually - the player is simply left at
        // whatever health they had a moment ago, which already reads
        // as "that was close."
        event.setCancelled(true);

        String causeDescription = describeCause(event, attacker, duel, id);
        plugin.duelManager().eliminate(duel, id, attacker, causeDescription);
    }

    /**
     * Whether this damage instance is even allowed to affect a duel's
     * outcome. Direct hits from a fellow, still-active participant
     * always count. "Environmental" causes (fall, lava, fire,
     * drowning) count only if listed in config - keeps the fight
     * feeling like real vanilla PVP (knockback into lava is a
     * legitimate tactic) without making literally anything fatal.
     * Damage from someone/something outside the duel is gated by
     * duel.allow-third-party-interference.
     */
    private boolean causeCanEndDuel(DamageCause cause, UUID attacker, ActiveDuel duel) {
        if (attacker != null && duel.participants().contains(attacker)
                && !duel.eliminated().contains(attacker)) {
            return true;
        }
        if (attacker != null) {
            return plugin.getConfig().getBoolean("duel.allow-third-party-interference", true);
        }
        List<String> envCauses = plugin.getConfig().getStringList("duel.environmental-causes");
        return envCauses.contains(cause.name());
    }

    private Optional<UUID> resolveAttacker(EntityDamageEvent event) {
        if (!(event instanceof EntityDamageByEntityEvent byEntity)) return Optional.empty();
        Entity damager = byEntity.getDamager();
        if (damager instanceof Player p) return Optional.of(p.getUniqueId());
        if (damager instanceof Projectile proj && proj.getShooter() instanceof Player shooter) {
            return Optional.of(shooter.getUniqueId());
        }
        return Optional.empty();
    }

    /**
     * Builds a vanilla-flavoured cause-of-death string. First pass
     * covering the common cases; wording is easy to tune later without
     * touching any of the actual duel logic above.
     */
    private String describeCause(EntityDamageEvent event, UUID attackerId, ActiveDuel duel, UUID victim) {
        if (!plugin.getConfig().getBoolean("messages.include-cause-of-death", true)) {
            return "was eliminated";
        }

        String attackerName = attackerId != null ? nameOf(attackerId) : null;

        if (attackerName != null) {
            return switch (event.getCause()) {
                case PROJECTILE -> "was shot by " + attackerName;
                case ENTITY_ATTACK, ENTITY_SWEEP_ATTACK -> "was slain by " + attackerName;
                default -> "was defeated by " + attackerName;
            };
        }

        var recent = duel.lastHitOn(victim, 5000);
        String context = recent != null ? " while fighting " + nameOf(recent.attacker()) : "";

        return switch (event.getCause()) {
            case FALL -> "fell from a high place" + context;
            case LAVA -> "tried to swim in lava" + context;
            case FIRE, FIRE_TICK -> "burned to a crisp" + context;
            case DROWNING -> "drowned" + context;
            default -> "was eliminated (" + event.getCause().name().toLowerCase().replace('_', ' ') + ")";
        };
    }

    private String nameOf(UUID id) {
        Player p = plugin.getServer().getPlayer(id);
        return p != null ? p.getName() : "someone";
    }
}
