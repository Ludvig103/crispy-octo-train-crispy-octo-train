package dk.ludvig.efterskole.duels.model;

/** Where a single player currently stands with respect to duelling. */
public enum DuelState {
    /** Free to challenge or be challenged. */
    NONE,
    /** Has sent a challenge and is waiting on the invitee(s). */
    PENDING_OUTGOING,
    /** Has been challenged and hasn't responded yet. */
    PENDING_INCOMING,
    /** Actively fighting in a resolved (all-accepted) duel. */
    IN_DUEL
}
