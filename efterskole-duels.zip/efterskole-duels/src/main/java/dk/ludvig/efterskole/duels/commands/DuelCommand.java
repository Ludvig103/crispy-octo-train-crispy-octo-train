package dk.ludvig.efterskole.duels.commands;

import dk.ludvig.efterskole.duels.DuelPlugin;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.stream.Collectors;

public final class DuelCommand implements CommandExecutor, TabCompleter {

    private final DuelPlugin plugin;

    public DuelCommand(DuelPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Players only.");
            return true;
        }

        if (args.length == 0) {
            player.sendMessage("Usage: /duel <player...> | accept | decline | leave | enable | disable");
            return true;
        }

        String sub = args[0].toLowerCase(Locale.ROOT);
        String result = switch (sub) {
            case "accept" -> plugin.duelManager().accept(player);
            case "decline" -> plugin.duelManager().decline(player);
            case "leave" -> plugin.duelManager().leave(player);
            case "enable" -> {
                plugin.playerPrefs().setDuelsEnabled(player.getUniqueId(), true);
                player.sendMessage("§aDuels enabled - you can be challenged again.");
                yield null;
            }
            case "disable" -> {
                plugin.playerPrefs().setDuelsEnabled(player.getUniqueId(), false);
                player.sendMessage("§7Duels disabled - you won't send or receive challenges.");
                yield null;
            }
            default -> handleChallenge(player, args);
        };

        if (result != null) {
            player.sendMessage(plugin.messages().errorText(result));
        }
        return true;
    }

    private String handleChallenge(Player player, String[] args) {
        Set<Player> targets = new LinkedHashSet<>();
        for (String name : args) {
            Player target = Bukkit.getPlayerExact(name);
            if (target == null) return "player-not-found:" + name;
            targets.add(target);
        }
        if (targets.isEmpty()) return "no-targets";
        return plugin.duelManager().challenge(player, targets);
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) return List.of();

        String partial = args[args.length - 1].toLowerCase(Locale.ROOT);

        if (args.length == 1) {
            List<String> options = new ArrayList<>(List.of("accept", "decline", "leave", "enable", "disable"));
            options.addAll(Bukkit.getOnlinePlayers().stream().map(Player::getName).toList());
            return options.stream().filter(o -> o.toLowerCase(Locale.ROOT).startsWith(partial))
                    .collect(Collectors.toList());
        }

        // Later args, for challenging multiple people at once.
        return Bukkit.getOnlinePlayers().stream().map(Player::getName)
                .filter(n -> n.toLowerCase(Locale.ROOT).startsWith(partial))
                .collect(Collectors.toList());
    }
}
