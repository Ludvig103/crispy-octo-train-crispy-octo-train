package dk.ludvig.efterskole.duels;

import dk.ludvig.efterskole.duels.commands.DuelCommand;
import org.bukkit.plugin.java.JavaPlugin;

public final class DuelPlugin extends JavaPlugin {

    private DuelManager duelManager;
    private DuelMessages messages;
    private GracePeriod gracePeriod;
    private Celebration celebration;
    private PlayerPrefs playerPrefs;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        this.messages = new DuelMessages(this);
        this.gracePeriod = new GracePeriod(this);
        this.celebration = new Celebration(this);
        this.playerPrefs = new PlayerPrefs(this);
        this.duelManager = new DuelManager(this);

        getServer().getPluginManager().registerEvents(new DamageListener(this), this);

        DuelCommand duelCommand = new DuelCommand(this);
        getCommand("duel").setExecutor(duelCommand);
        getCommand("duel").setTabCompleter(duelCommand);

        getLogger().info("EfterskoleDuels enabled.");
    }

    public DuelManager duelManager() { return duelManager; }
    public DuelMessages messages() { return messages; }
    public GracePeriod gracePeriod() { return gracePeriod; }
    public Celebration celebration() { return celebration; }
    public PlayerPrefs playerPrefs() { return playerPrefs; }
}
