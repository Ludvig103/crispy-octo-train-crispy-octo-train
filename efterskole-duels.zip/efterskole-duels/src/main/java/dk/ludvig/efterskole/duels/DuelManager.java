package dk.ludvig.efterskole.duels;

import dk.ludvig.efterskole.duels.model.ActiveDuel;
import dk.ludvig.efterskole.duels.model.DuelState;
import dk.ludvig.efterskole.duels.model.PendingChallenge;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

/**
 * Owns all duel state: who's pending what, who's actively fighting.
 * This first pass focuses entirely on getting the state machine and
 * the "only one thing pending at a time" rule right; exact message
 * wording lives in DuelMessages so it can be tuned separately without
 * touching this logic.
 */
public final class DuelManager {

    private final DuelPlugin plugin;

    private final Map<UUID, DuelState> states = new HashMap<>();
    private final Map<UUID, PendingChallenge> pendingByPlayer = new HashMap<>();
    private final Map<UUID, ActiveDuel> activeByPlayer = new HashMap<>();
    private final Map<UUID, Long> cooldownUntil = new HashMap<>();

    public DuelManager(DuelPlugin plugin) {
        this.plugin = plugin;
    }

    public DuelState stateOf(UUID player) {
        return states.getOrDefault(player, DuelState.NONE);
    }

    public boolean onCooldown(UUID player) {
        Long until = cooldownUntil.get(player);
        return until != null && until > System.currentTimeMillis();
    }

    // ---- Challenge lifecycle -------------------------------------------

    /**
     * @return an error key if the challenge couldn't be sent, or null
     *         on success. Keys are handled by DuelMessages#errorText.
     */
    public String challenge(Player challenger, Set<Player> targets) {
        UUID challengerId = challenger.getUniqueId();

        if (stateOf(challengerId) != DuelState.NONE) return "you-already-pending-or-duelling";
        if (onCooldown(challengerId)) return "you-on-cooldown";
        if (!plugin.playerPrefs().duelsEnabled(challengerId)) return "you-have-duels-disabled";

        for (Player t : targets) {
            UUID id = t.getUniqueId();
            if (id.equals(challengerId)) return "cannot-challenge-self";
            if (stateOf(id) != DuelState.NONE) return "target-already-pending-or-duelling";
            if (onCooldown(id)) return "target-on-cooldown";
            if (!plugin.playerPrefs().duelsEnabled(id)) return "target-has-duels-disabled";
        }

        Set<UUID> invitedIds = new LinkedHashSet<>();
        for (Player t : targets) invitedIds.add(t.getUniqueId());

        PendingChallenge challengeObj = new PendingChallenge(challengerId, invitedIds);

        states.put(challengerId, DuelState.PENDING_OUTGOING);
        pendingByPlayer.put(challengerId, challengeObj);
        for (UUID id : invitedIds) {
            states.put(id, DuelState.PENDING_INCOMING);
            pendingByPlayer.put(id, challengeObj);
        }

        int timeoutSeconds = plugin.getConfig().getInt("invite.timeout-seconds", 60);
        BukkitTask task = Bukkit.getScheduler().runTaskLater(plugin, () -> expire(challengeObj),
                timeoutSeconds * 20L);
        challengeObj.setTimeoutTask(task);

        plugin.messages().announceChallenge(challengeObj);
        return null;
    }

    public String accept(Player player) {
        UUID id = player.getUniqueId();
        PendingChallenge challenge = pendingByPlayer.get(id);
        if (challenge == null || stateOf(id) != DuelState.PENDING_INCOMING) {
            return "no-pending-invite";
        }

        challenge.accepted().add(id);

        if (challenge.isFullyAccepted()) {
            startDuel(challenge);
        } else {
            plugin.messages().announceAccepted(challenge, id);
        }
        return null;
    }

    public String decline(Player player) {
        UUID id = player.getUniqueId();
        PendingChallenge challenge = pendingByPlayer.get(id);
        if (challenge == null) return "no-pending-invite";
        cancelChallenge(challenge, id, "declined");
        return null;
    }

    private void expire(PendingChallenge challenge) {
        // Guards against a stale scheduled task firing after the
        // challenge was already resolved another way.
        if (pendingByPlayer.get(challenge.challenger()) != challenge) return;
        cancelChallenge(challenge, null, "timed-out");
    }

    private void cancelChallenge(PendingChallenge challenge, UUID actor, String reason) {
        if (challenge.timeoutTask() != null) challenge.timeoutTask().cancel();
        for (UUID id : challenge.everyone()) {
            states.put(id, DuelState.NONE);
            pendingByPlayer.remove(id);
        }
        plugin.messages().announceCancelled(challenge, actor, reason);
    }

    private void startDuel(PendingChallenge challenge) {
        if (challenge.timeoutTask() != null) challenge.timeoutTask().cancel();

        Set<UUID> participants = challenge.everyone();
        ActiveDuel duel = new ActiveDuel(participants);
        for (UUID id : participants) {
            states.put(id, DuelState.IN_DUEL);
            pendingByPlayer.remove(id);
            activeByPlayer.put(id, duel);
        }
        plugin.messages().announceStart(duel);
    }

    // ---- Active duel handling -------------------------------------------

    public Optional<ActiveDuel> activeDuelOf(UUID player) {
        return Optional.ofNullable(activeByPlayer.get(player));
    }

    /** Called by DamageListener once it's decided a hit was fatal. */
    public void eliminate(ActiveDuel duel, UUID loser, UUID attackerOrNull, String causeDescription) {
        duel.eliminated().add(loser);
        activeByPlayer.remove(loser);
        states.put(loser, DuelState.NONE);
        applyCooldown(loser);

        plugin.messages().announceElimination(duel, loser, attackerOrNull, causeDescription);
        plugin.gracePeriod().protect(loser);

        if (duel.isOver()) {
            UUID winner = duel.winner();
            for (UUID p : duel.participants()) {
                activeByPlayer.remove(p);
                if (states.get(p) == DuelState.IN_DUEL) states.put(p, DuelState.NONE);
                applyCooldown(p);
            }
            plugin.messages().announceWinner(duel, winner);
            if (winner != null) plugin.celebration().celebrate(winner);
        }
    }

    public String leave(Player player) {
        UUID id = player.getUniqueId();
        DuelState state = stateOf(id);

        if (state == DuelState.PENDING_INCOMING || state == DuelState.PENDING_OUTGOING) {
            return decline(player);
        }
        if (state == DuelState.IN_DUEL) {
            ActiveDuel duel = activeByPlayer.get(id);
            eliminate(duel, id, null, "forfeited the duel");
            return null;
        }
        return "not-in-a-duel";
    }

    private void applyCooldown(UUID player) {
        int seconds = plugin.getConfig().getInt("duel.cooldown-seconds", 30);
        cooldownUntil.put(player, System.currentTimeMillis() + seconds * 1000L);
    }
}
