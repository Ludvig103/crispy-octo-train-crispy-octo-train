package dk.ludvig.efterskole.duels;

import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.FireworkEffect;
import org.bukkit.Location;
import org.bukkit.entity.Firework;
import org.bukkit.entity.Player;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.UUID;

/**
 * Purely decorative firework burst for the duel winner. Spawned
 * directly as a Firework entity (not launched from a dispenser or
 * crossbow), which means it does NOT deal explosion damage to the
 * winner or any bystanders - it's just the visual + sound.
 */
public final class Celebration {

    private final DuelPlugin plugin;

    public Celebration(DuelPlugin plugin) {
        this.plugin = plugin;
    }

    public void celebrate(UUID winnerId) {
        if (!plugin.getConfig().getBoolean("celebration.fireworks-enabled", true)) return;

        Player winner = Bukkit.getPlayer(winnerId);
        if (winner == null) return;

        int count = plugin.getConfig().getInt("celebration.firework-count", 3);
        Location loc = winner.getLocation();

        new BukkitRunnable() {
            int launched = 0;

            @Override
            public void run() {
                if (launched >= count || !winner.isOnline()) {
                    cancel();
                    return;
                }
                spawnOne(loc.clone().add(0, 1, 0));
                launched++;
            }
        }.runTaskTimer(plugin, 0L, 8L); // spaced out a bit, reads as a little show rather than one bang
    }

    private void spawnOne(Location loc) {
        Firework firework = loc.getWorld().spawn(loc, Firework.class);
        FireworkMeta meta = firework.getFireworkMeta();
        meta.addEffect(FireworkEffect.builder()
                .with(FireworkEffect.Type.BALL_LARGE)
                .withColor(Color.YELLOW, Color.ORANGE)
                .withFade(Color.WHITE)
                .withTrail()
                .withFlicker()
                .build());
        meta.setPower(1);
        firework.setFireworkMeta(meta);
        firework.detonate(); // explode immediately - a celebration, not a launch
    }
}
