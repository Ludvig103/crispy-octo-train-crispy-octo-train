# EfterskoleDuels - first architectural sketch

This is a first pass at the plugin, not a finished build. It's meant to
be reviewed and poked at before we treat it as final.

## What's fleshed out

- The full state machine: `NONE / PENDING_OUTGOING / PENDING_INCOMING /
  IN_DUEL`, enforcing "only one thing pending at a time," including for
  group (3+) challenges.
- The 60-second auto-decline timer.
- Damage interception: cancels a fatal hit, decides whether the cause
  is allowed to end a duel (direct hits from a live participant always
  count; fall/lava/fire/drowning count if listed in config; outside
  interference is a config toggle), and builds a vanilla-flavoured
  cause-of-death string.
- The post-duel grace period: extinguishes fire immediately, attempts
  a short safe-location teleport out of lava, and backstops with a
  short, narrowly-scoped (fire/lava/drowning only) damage immunity
  that resets rather than stacks.
- `/duel disable` and `/duel enable`, persisted per player in a small
  YAML file.
- The challenge prompt: coloured chat message with the commands always
  spelled out in plain text, a clickable accept/decline for Java
  players layered on top, a Title flash, and a sound - so it's hard to
  miss on any platform even without click support.
- Winner fireworks (purely decorative, no explosion damage).
- `config.yml` with everything above exposed as a setting.

## What's deliberately left as a stub

`DuelMessages#announceAccepted/announceCancelled/announceStart` are
empty - low-risk wording to fill in once the logic above is confirmed
solid. Didn't want to spend review time on chat copy before the parts
that could actually cause a bug (state machine, damage handling).

## One open question before this goes further

You mentioned both a "duel cooldown timer" and "duel duration" as
config values you'd want. Cooldown is implemented
(`duel.cooldown-seconds` - time before you can duel again after one
ends). "Duel duration" is ambiguous to me: it could mean the 60-second
invite window (already configurable, `invite.timeout-seconds`), or it
could mean a cap on how long the **fight itself** is allowed to run
before it's forced to a draw. I didn't want to guess and build a whole
draw-resolution system you didn't ask for - see the commented-out
`duel.max-fight-seconds` in config.yml. Let me know which you meant
(or if it's genuinely both).

## Before you build this

- **Not compiled or run** - I don't have network access to Paper's
  Maven repository from this sandbox, so this has only been checked by
  hand against APIs I'm confident about, not by an actual compiler.
  Please run `mvn package` on your own machine (or wherever you build)
  before trusting it, and send me any compiler errors - there's a
  decent chance of a small one somewhere in code this size that I
  haven't been able to verify mechanically.
- Needs Java 25 to build and run, matching what you confirmed for your
  server.
- Drop the built jar into Purpur's `plugins/` folder via your
  Pterodactyl file manager, like any other plugin.
